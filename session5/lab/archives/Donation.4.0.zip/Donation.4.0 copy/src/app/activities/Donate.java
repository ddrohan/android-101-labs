package app.activities;

import app.donation.R;
import app.models.Donation;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Donate extends Base
{
  private RadioGroup   paymentMethod;
  private ProgressBar  progressBar;
  private NumberPicker amountPicker;
  private TextView     amountText;
  private TextView     amountTotal;
  private SharedPreferences settings;
  
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_donate);
    
    paymentMethod = (RadioGroup)   findViewById(R.id.paymentMethod);
    progressBar   = (ProgressBar)  findViewById(R.id.progressBar);
    amountPicker  = (NumberPicker) findViewById(R.id.amountPicker);
    amountText    = (TextView)     findViewById(R.id.amountText);
    amountTotal   = (TextView)     findViewById(R.id.amountTotal);
    
    amountPicker.setMinValue(0);
    amountPicker.setMaxValue(1000);
    progressBar.setMax(app.target);
    amountTotal.setText("$" + app.totalDonated);
    
    settings = getSharedPreferences("loginPrefs", 0);
    String username = settings.getString("username", "");
    
    TextView donateUsername = (TextView) findViewById(R.id.donateUsername);
    
    SpannableString spanString = new SpannableString(username);
    spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), 0);
    spanString.setSpan(new StyleSpan(Typeface.BOLD), 0, spanString.length(), 0);
    spanString.setSpan(new StyleSpan(Typeface.ITALIC), 0, spanString.length(), 0);
    donateUsername.setText(spanString);
    
  }

  @Override
  public void reset(MenuItem item)
  {
	  	app.dbManager.reset();
		app.totalDonated = 0;
		amountTotal.setText("$" + app.totalDonated);
  } 
  
  public void donateButtonPressed (View view) 
  {
    String method = paymentMethod.getCheckedRadioButtonId() == R.id.PayPal ? "PayPal" : "Direct";
    int donatedAmount =  amountPicker.getValue();
    if (donatedAmount == 0)
    {
      String text = amountText.getText().toString();
      if (!text.equals(""))
        donatedAmount = Integer.parseInt(text);
    }
    if (donatedAmount > 0)
    {
      app.newDonation(new Donation(donatedAmount, method));
      progressBar.setProgress(app.totalDonated);
      String totalDonatedStr = "$" + app.totalDonated;
      amountTotal.setText(totalDonatedStr);
    }
   }
}
