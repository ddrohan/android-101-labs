package app.db;

import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import app.activities.Base;
import app.models.Donation;

public class DBManager {

	private SQLiteDatabase database;
	private DBDesigner dbHelper;

	public DBManager(Context context) {
		dbHelper = new DBDesigner(context);
	}

	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}

	public void close() {
		database.close();
	}

	public void add(Donation d) {
		ContentValues values = new ContentValues();
		values.put(DBDesigner.COLUMN_AMOUNT, d.amount);
		values.put(DBDesigner.COLUMN_METHOD, d.method);

		database.insert(DBDesigner.TABLE_DONATION, null, values);
	}

	public List<Donation> getAll() {
		List<Donation> donations = new ArrayList<Donation>();
		Cursor cursor = database.rawQuery("SELECT * FROM "
				+ DBDesigner.TABLE_DONATION, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Donation d = toDonation(cursor);
			donations.add(d);
			cursor.moveToNext();
		}
		cursor.close();
		return donations;
	}

	public Donation get(int id) {
		Donation d = null;
		Cursor cursor = database.rawQuery("SELECT * FROM "
				+ DBDesigner.TABLE_DONATION + " WHERE "
				+ DBDesigner.COLUMN_ID + " = " + id , null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Donation temp = toDonation(cursor);
			d = temp;
			cursor.moveToNext();
		}
		cursor.close();
		return d;
	}
	private Donation toDonation(Cursor cursor) {
		Donation pojo = new Donation();
		pojo.id = cursor.getInt(0);
		pojo.amount = cursor.getInt(1);
		pojo.method = cursor.getString(2);
		return pojo;
	}

	public void setTotalDonated(Base base) {
		Cursor c = database.rawQuery("SELECT SUM(" + DBDesigner.COLUMN_AMOUNT + ") FROM " 
									+ DBDesigner.TABLE_DONATION, null);
		c.moveToFirst();
		if (!c.isAfterLast())
			base.app.totalDonated = c.getInt(0);
	}

	public void reset() {
		database.delete(DBDesigner.TABLE_DONATION, null, null);
	}
}
