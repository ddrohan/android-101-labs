package app.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBDesigner extends SQLiteOpenHelper {
	public static final String 	TABLE_DONATION = "table_donation";
	public static final String 	COLUMN_ID = "id";
	public static final String 	COLUMN_AMOUNT = "amount";
	public static final String 	COLUMN_METHOD = "method";
	private static final String DATABASE_NAME = "donations.db";
	private static final int 	DATABASE_VERSION = 1;
	private static final String DATABASE_CREATE_TABLE_DONATION = "create table "
			+ TABLE_DONATION + "( " + COLUMN_ID + " integer primary key autoincrement, " 
			+ COLUMN_AMOUNT + " integer not null,"
			+ COLUMN_METHOD + " text not null);";
		
	public DBDesigner(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase database) {
		database.execSQL(DATABASE_CREATE_TABLE_DONATION);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Log.w(DBDesigner.class.getName(),
				"Upgrading database from version " + oldVersion + " to "
						+ newVersion + ", which will destroy all old data");
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_DONATION);
		onCreate(db);
	}
}